# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

A SCORM 1.2 compliant math quiz e-learning package for LMS deployment. Written in Polish. No build system — vanilla HTML/CSS/JS only.

## Deployment

Package the entire directory as a ZIP file for LMS import. The SCORM manifest (`imsmanifest.xml`) defines the package structure. To test locally without an LMS, the SCORM API calls will silently fail (the quiz still renders, but progress won't persist).

## Quiz data file

Questions live in a separate `.js` file loaded at runtime via the `?quiz=` URL parameter:

```
index.html               ← loads questions.js (default)
index.html?quiz=algebra.js   ← loads algebra.js
```

`quiz.js` injects a `<script>` tag (not `fetch`) so it works with both `file://` and `http://` — important for local testing without a server.

The file must assign `window.QUIZ_DATA`:

```js
window.QUIZ_DATA = {
  title: "Quiz matematyczny 2.0",   // sets document.title
  passScore: 80,                    // defaults to 80 if omitted
  questions: [
    { id: 1, question: "2 + 3 = ?", options: ["4","5","6","7"], correct: 1 }
  ]
};
```

`correct` is a zero-based index into `options`.

## Architecture

Two-module design with clean separation of concerns:

- **`scorm.js`** — SCORM 1.2 API wrapper. Discovers the LMS API by traversing the `window` parent/opener hierarchy (up to 20 levels). Exposes `init()`, `finish()`, `getValue()`, `setValue()`, `save()`. All LMS communication goes through here.

- **`quiz.js`** — Quiz engine. Manages state, renders UI, and orchestrates SCORM calls. State is a plain JS object serialized as JSON into `cmi.suspend_data` for cross-session persistence.

- **`index.html`** — Entry point. Static DOM shell; quiz content is rendered dynamically by `quiz.js`.

## Key Data Flow

1. On load: `scorm.init()` → read `cmi.suspend_data` → restore previous state (answers, submitted flag, score)
2. Answer selection → update `state.answers` → update progress bar
3. "Save Progress" button → serialize state to JSON → `scorm.setValue('cmi.suspend_data', ...)` → `scorm.save()`
4. "Submit" button → grade answers → `scorm.setValue('cmi.core.score.raw', score)` + `scorm.setValue('cmi.core.lesson_status', 'passed'|'failed')` → `scorm.finish()`
5. Page unload → auto-save + `scorm.finish()`

## Important Constants

- **Pass threshold:** `PASS_SCORE = 0.8` (80%) in `quiz.js`
- **Questions:** 5 hardcoded math questions in the `questions` array in `quiz.js`
- **SCORM version:** 1.2 (LMSInitialize, not Initialize — do not confuse with SCORM 2004)

## SCORM 1.2 Data Model Keys Used

| Key | Purpose |
|-----|---------|
| `cmi.suspend_data` | JSON-serialized quiz state (answers, score, submitted) |
| `cmi.core.score.raw` | Numeric score (0–100) |
| `cmi.core.lesson_status` | `passed`, `failed`, or `incomplete` |
| `cmi.core.session_time` | Session duration |
